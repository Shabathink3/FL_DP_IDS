# Code of Conduct

## Our Pledge

We are committed to providing a welcoming and inspiring community for all. We pledge that everyone participating in the FL_DP_IDS community will be treated with respect and dignity, regardless of their identity or background.

## Our Standards

Examples of behavior that contributes to creating a positive environment include:
- Being respectful and inclusive
- Being constructive in criticism
- Focusing on what is best for the community
- Showing empathy towards other community members
- Using welcoming and inclusive language

Examples of unacceptable behavior include:
- Harassment, discrimination, or bullying
- Offensive comments, insults, or threats
- Publishing others' private information without consent
- Other conduct that could reasonably be considered inappropriate

## Enforcement

Instances of unacceptable behavior may be reported by contacting the project maintainers. All reports will be reviewed and investigated appropriately. All community members are expected to follow this Code of Conduct.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/).
