# Contributing to FL_DP_IDS

Thank you for your interest in contributing to Federated Learning with Differential Privacy for Intrusion Detection! This document provides guidelines and instructions for contributing.

## 🎯 Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please see [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) for our community standards.

## 📋 Ways to Contribute

### 1. **Report Bugs**
Found a bug? Please open an issue with:
- Clear title and description
- Steps to reproduce
- Expected vs actual behavior
- Environment (OS, Python version, etc.)
- Screenshots or error messages if applicable

### 2. **Suggest Features**
Have an idea? Please open a feature request with:
- Clear description of the feature
- Why it would be useful
- Possible implementation approach (optional)

### 3. **Improve Documentation**
Documentation improvements are always welcome:
- Fix typos or unclear explanations
- Add examples
- Improve code comments
- Create tutorials

### 4. **Write Tests**
Help improve test coverage:
- Write unit tests for new features
- Add integration tests
- Report untested code

### 5. **Submit Code**
Contribute code improvements:
- Bug fixes
- New features
- Performance improvements
- Code refactoring

## 🚀 Getting Started

### Set Up Development Environment

```bash
# 1. Fork the repository on GitHub

# 2. Clone your fork
git clone https://github.com/YOUR_USERNAME/FL_DP_IDS.git
cd FL_DP_IDS

# 3. Add upstream remote
git remote add upstream https://github.com/username/FL_DP_IDS.git

# 4. Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 5. Install development dependencies
pip install -e ".[dev]"

# 6. Install pre-commit hooks (optional)
pip install pre-commit
pre-commit install
```

### Development Workflow

```bash
# 1. Create feature branch
git checkout -b feature/your-feature-name

# 2. Make changes and commit
git add .
git commit -m "feat: Add your feature description"

# 3. Run tests
pytest tests/ -v

# 4. Check code style
black src/
flake8 src/
mypy src/

# 5. Push to your fork
git push origin feature/your-feature-name

# 6. Open Pull Request on GitHub
```

## 📝 Commit Message Guidelines

Follow [Conventional Commits](https://www.conventionalcommits.org/) format:

```
type(scope): subject

body

footer
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style (formatting, missing semicolons, etc.)
- `refactor`: Code refactoring
- `perf`: Performance improvement
- `test`: Tests
- `chore`: Build, CI, dependencies

**Examples:**
```
feat(fl): Implement Byzantine-robust aggregation
fix(dp): Fix privacy budget calculation in DP-SGD
docs: Add tutorial for privacy-utility trade-off
test(dataset): Add unit tests for data preprocessing
```

## 🧪 Testing Requirements

All contributions must include tests:

```bash
# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html

# Run specific test
pytest tests/test_fl.py::TestFederatedLearningServer -v
```

**Coverage Requirements:**
- Minimum 80% code coverage for new code
- All public functions must have tests
- Include both positive and negative test cases

## 📐 Code Style

We follow [PEP 8](https://www.python.org/dev/peps/pep-0008/) style guide:

```bash
# Format code with Black
black src/ tests/

# Check style with flake8
flake8 src/ tests/

# Type checking with mypy
mypy src/
```

**Code Quality Standards:**
- Maximum line length: 100 characters
- Use meaningful variable names
- Add docstrings to all functions
- Include type hints
- Write descriptive comments

## 📖 Documentation

All code must be documented:

### Docstring Format

```python
def federated_learning_round(self, model_type='mlp', use_dp=False):
    """
    Execute one round of federated learning.
    
    Performs local training on each client, then aggregates
    model updates using FedAvg algorithm.
    
    Args:
        model_type (str): Type of model ('mlp', 'rf', 'lr').
            Defaults to 'mlp'.
        use_dp (bool): Whether to use Differential Privacy.
            Defaults to False.
    
    Returns:
        list: List of dicts with local metrics from each client.
            Each dict contains 'accuracy', 'f1', 'auc' keys.
    
    Raises:
        ValueError: If model_type is not supported.
        RuntimeError: If no clients registered.
    
    Example:
        >>> server = FederatedLearningServer(num_clients=5)
        >>> metrics = server.federated_learning_round(model_type='mlp')
        >>> print(f"Round accuracy: {metrics[0]['accuracy']}")
    """
```

### Comment Guidelines

```python
# Good: Clear and concise
x = model.predict(X)  # Get predictions for test set

# Bad: Obvious or unclear
x = m.p(X)  # x is result

# Good: Explain why, not what
# Use sigmoid instead of ReLU for binary classification
activation = 'sigmoid'

# Bad: Explaining obvious code
# Set x to 5
x = 5
```

## 🔄 Pull Request Process

1. **Before Starting**
   - Check existing issues and PRs to avoid duplicates
   - Discuss major changes in an issue first

2. **While Developing**
   - Keep commits atomic and logical
   - Write clear commit messages
   - Add tests for new functionality
   - Update documentation

3. **Before Submitting**
   - Run all tests: `pytest tests/`
   - Check code style: `black` and `flake8`
   - Update CHANGELOG.md
   - Ensure PR title is descriptive

4. **Pull Request Template**
   ```markdown
   ## Description
   Brief description of changes
   
   ## Related Issue
   Closes #(issue number)
   
   ## Type of Change
   - [ ] Bug fix
   - [ ] New feature
   - [ ] Breaking change
   - [ ] Documentation update
   
   ## Testing
   - [ ] Tests pass locally
   - [ ] Added new tests
   - [ ] All tests pass
   
   ## Checklist
   - [ ] Code follows style guidelines
   - [ ] Documentation updated
   - [ ] No breaking changes
   ```

5. **Review Process**
   - Maintainers will review code
   - Address feedback and make changes
   - Keep discussion professional and constructive

## 📊 Review Criteria

PRs will be evaluated on:
- **Correctness**: Does it work correctly?
- **Code Quality**: Is it maintainable and readable?
- **Testing**: Is it adequately tested?
- **Documentation**: Is it well documented?
- **Performance**: Does it impact performance negatively?
- **Security**: Are there security concerns?
- **Compatibility**: Does it break existing functionality?

## 🐛 Bug Report Template

```markdown
# Bug Report

## Description
Clear description of the bug

## Steps to Reproduce
1. ...
2. ...
3. ...

## Expected Behavior
What should happen

## Actual Behavior
What actually happened

## Environment
- OS: (e.g., Ubuntu 20.04)
- Python: (e.g., 3.9)
- Version: (e.g., 1.0.0)

## Screenshots
Include screenshots if applicable

## Minimal Example
```python
# Code that reproduces the bug
```
```

## ✨ Feature Request Template

```markdown
# Feature Request

## Description
Clear description of the feature

## Motivation
Why would this be useful?

## Proposed Solution
How should it work?

## Alternative Solutions
Any alternatives considered?

## Additional Context
Any other information
```

## 📚 Additional Resources

- [Project README](README.md)
- [API Documentation](docs/API.md)
- [Methodology](docs/METHODOLOGY.md)
- [Code of Conduct](CODE_OF_CONDUCT.md)

## 🙋 Questions?

- Check [FAQ](docs/TROUBLESHOOTING.md)
- Open a [GitHub Discussion](https://github.com/username/FL_DP_IDS/discussions)
- Email maintainers

## 🎉 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- GitHub contributors graph

Thank you for contributing! 🚀
