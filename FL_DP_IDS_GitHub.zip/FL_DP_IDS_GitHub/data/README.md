# CIC-IDS2017 Dataset

This directory contains the CIC-IDS2017 (Canadian Institute for Cybersecurity Intrusion Detection Dataset) used for federated learning evaluation.

## Dataset Overview

- **Source**: Canadian Institute for Cybersecurity, University of New Brunswick
- **URL**: https://www.unb.ca/cic/datasets/ids-2017.html
- **License**: Creative Commons Attribution 4.0 International
- **Total Flows**: 2.83 million
- **Features**: 80+ network flow statistics
- **Time Period**: January 9-13, 2017 (Monday-Friday)
- **Benign Traffic**: ~80%
- **Attack Traffic**: ~20%

## Download Instructions

### Option 1: Automatic Download (Python)

```python
from src.dataset import CICIDSDataLoader

loader = CICIDSDataLoader()
loader.download_dataset(output_dir='data/cicids2017/')
```

### Option 2: Manual Download

1. Visit: https://www.unb.ca/cic/datasets/ids-2017.html
2. Download all Monday-Friday CSV files
3. Extract to `data/cicids2017/` directory

### Option 3: Using Wget

```bash
cd data/cicids2017/

# Download all files
wget https://www.unb.ca/cic/datasets/ids-2017/Monday-WorkingHours.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Tuesday-WorkingHours.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Wednesday-workingHours.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Thursday-WorkingHours-Morning.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Thursday-WorkingHours-Afternoon.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Friday-WorkingHours-Morning.pcap_ISCX.csv
wget https://www.unb.ca/cic/datasets/ids-2017/Friday-WorkingHours-Afternoon.pcap_ISCX.csv
```

## Expected Structure

After downloading, your `data/cicids2017/` should contain:

```
data/cicids2017/
├── Monday-WorkingHours.pcap_ISCX.csv
├── Tuesday-WorkingHours.pcap_ISCX.csv
├── Wednesday-workingHours.pcap_ISCX.csv
├── Thursday-WorkingHours-Morning.pcap_ISCX.csv
├── Thursday-WorkingHours-Afternoon.pcap_ISCX.csv
├── Friday-WorkingHours-Morning.pcap_ISCX.csv
└── Friday-WorkingHours-Afternoon.pcap_ISCX.csv
```

## Dataset Statistics

| Day | Flows | Benign | Attack | Attack Types |
|-----|-------|--------|--------|--------------|
| Monday | 560K | 100% | 0% | None (baseline) |
| Tuesday | 294K | 97% | 3% | Brute Force SSH |
| Wednesday | 445K | 98% | 2% | DoS / DDoS |
| Thursday | 686K | 92% | 8% | Web Attacks |
| Friday | 843K | 81% | 19% | Botnet, Infiltration |

## Preprocessing

The dataset includes 80+ features such as:

- **Packet-level statistics**: Packet sizes, inter-arrival times
- **Flow-level statistics**: Flow duration, packet counts
- **Protocol information**: Protocol distribution, flags
- **Statistical measures**: Means, standard deviations, minimums, maximums

Key preprocessing steps:
1. Handle missing values (replace with 0)
2. Normalize numerical features (StandardScaler)
3. Binary classification: Normal vs Attack
4. Remove duplicate/irrelevant features

## Using the Dataset

### Load and Preprocess

```python
from src.dataset import CICIDSDataLoader
from sklearn.preprocessing import StandardScaler

loader = CICIDSDataLoader('data/cicids2017/')
X_train, X_test, y_train, y_test = loader.load_processed_data(test_size=0.2)

# Data is already normalized
print(f"Training set: {X_train.shape}")  # (n_samples, 20)
print(f"Test set: {X_test.shape}")
```

### Generate Synthetic Data for Testing

For quick testing without full dataset:

```python
from src.dataset import CICIDSDatasetSimulator

X, y = CICIDSDatasetSimulator.generate_cicds_like_data(n_samples=10000)
clients_data = CICIDSDatasetSimulator.split_by_days(X, y, num_days=5)
```

## Citations

If you use the CIC-IDS2017 dataset, please cite:

```bibtex
@article{sharafaldin2018cicids2017,
  title={Toward generating a new intrusion detection dataset and intrusion traffic characterization},
  author={Sharafaldin, Iman and Lashkari, Arash Habibi and Ghorbani, Ali A},
  journal={In ICISSP},
  pages={108--116},
  year={2018}
}
```

## License

The CIC-IDS2017 dataset is licensed under:
**Creative Commons Attribution 4.0 International (CC BY 4.0)**

This means you can:
- ✅ Use for commercial and non-commercial purposes
- ✅ Modify and adapt the dataset
- ✅ Distribute the dataset

You must:
- ✓ Provide attribution to the Canadian Institute for Cybersecurity
- ✓ Include a copy of the license

See: https://creativecommons.org/licenses/by/4.0/

## Storage Requirements

- **Uncompressed**: ~1.2 GB
- **Compressed (.zip)**: ~300 MB
- **After preprocessing**: ~200 MB (as HDF5)

## Privacy Notice

This dataset contains real network traffic from a production network. While sanitized to remove personally identifiable information, exercise caution when sharing or publishing results based on specific flow patterns.

## Support

- **Original Dataset**: https://www.unb.ca/cic/datasets/ids-2017.html
- **Paper**: https://doi.org/10.1109/ICISSP.2018.8394286
- **Issues/Questions**: Open a GitHub issue in this repository

---

**Last Updated**: November 28, 2025
