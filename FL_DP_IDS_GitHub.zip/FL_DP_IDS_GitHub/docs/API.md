# API Reference

## Core Classes

### DifferentialPrivacyDPSGD

Implements Differential Privacy via Stochastic Gradient Descent.

```python
class DifferentialPrivacyDPSGD:
    def __init__(self, epsilon=1.0, delta=1e-5, max_grad_norm=1.0)
    def add_noise(self, gradient) -> np.ndarray
    def get_privacy_budget(self, steps) -> float
```

#### Parameters
- `epsilon` (float): Privacy budget parameter. Lower = stronger privacy.
- `delta` (float): Probability of violating epsilon-DP guarantee.
- `max_grad_norm` (float): Maximum L2 norm for gradient clipping.

#### Methods

**`add_noise(gradient)`**
- Clips gradient to max_grad_norm
- Adds Gaussian noise to clipped gradient
- Returns noisy gradient
- **Args**: gradient (np.ndarray)
- **Returns**: np.ndarray - Noisy gradient

**`get_privacy_budget(steps)`**
- Calculates privacy loss after k training steps
- Uses composition accounting
- **Args**: steps (int) - Number of training steps
- **Returns**: float - Epsilon value after composition

#### Example
```python
from fl_dp_ids import DifferentialPrivacyDPSGD

dp = DifferentialPrivacyDPSGD(epsilon=1.0, delta=1e-5)
gradient = np.random.randn(100)  # Sample gradient
noisy_gradient = dp.add_noise(gradient)
privacy_budget = dp.get_privacy_budget(steps=100)
print(f"Privacy after 100 steps: ε={privacy_budget:.2f}")
```

---

### FederatedClient

Represents a single client/organization in federated learning.

```python
class FederatedClient:
    def __init__(self, client_id, X_train, y_train, X_test, y_test,
                 use_dp=False, epsilon=1.0)
    def train_local_model(self, model_type='rf', epochs=5) -> dict
    def evaluate(self) -> dict
```

#### Parameters
- `client_id` (int): Unique client identifier
- `X_train` (np.ndarray): Training features
- `y_train` (np.ndarray): Training labels
- `X_test` (np.ndarray): Test features
- `y_test` (np.ndarray): Test labels
- `use_dp` (bool): Whether to apply differential privacy
- `epsilon` (float): Privacy budget (if use_dp=True)

#### Methods

**`train_local_model(model_type='rf', epochs=5)`**
- Trains model locally on client data
- Optionally applies DP-SGD
- **Args**:
  - `model_type` (str): 'rf' (Random Forest), 'mlp' (MLP), or 'lr' (Logistic Regression)
  - `epochs` (int): Number of training epochs (for MLP)
- **Returns**: dict with keys 'accuracy', 'precision', 'recall', 'f1', 'auc'

**`evaluate()`**
- Evaluates current model on test set
- **Returns**: dict with performance metrics

#### Example
```python
from fl_dp_ids import FederatedClient
from sklearn.datasets import make_classification

X, y = make_classification(n_samples=1000, n_features=20)
X_train, X_test = X[:800], X[800:]
y_train, y_test = y[:800], y[800:]

client = FederatedClient(
    client_id=0,
    X_train=X_train, y_train=y_train,
    X_test=X_test, y_test=y_test,
    use_dp=True, epsilon=1.0
)

metrics = client.train_local_model(model_type='mlp', epochs=10)
print(f"Accuracy: {metrics['accuracy']:.4f}")
```

---

### FederatedLearningServer

Coordinates federated learning rounds and aggregates client models.

```python
class FederatedLearningServer:
    def __init__(self, num_clients=5)
    def add_client(self, client) -> None
    def aggregate_models(self) -> model
    def federated_learning_round(self, model_type='rf', use_dp=False) -> list
```

#### Parameters
- `num_clients` (int): Expected number of clients

#### Methods

**`add_client(client)`**
- Registers a FederatedClient with the server
- **Args**: client (FederatedClient)

**`aggregate_models()`**
- Performs FedAvg aggregation of client models
- Trains new model on combined client data
- **Returns**: Aggregated model object

**`federated_learning_round(model_type='rf', use_dp=False)`**
- Executes one round of federated learning
- Each client trains locally, server aggregates
- **Args**:
  - `model_type` (str): Type of model
  - `use_dp` (bool): Whether clients use DP
- **Returns**: list of dicts with local metrics from each client

#### Example
```python
from fl_dp_ids import FederatedLearningServer, FederatedClient

# Create server
server = FederatedLearningServer(num_clients=5)

# Create and register clients (setup clients_data first)
for i, (X_tr, y_tr, X_te, y_te) in enumerate(clients_data):
    client = FederatedClient(
        client_id=i,
        X_train=X_tr, y_train=y_tr,
        X_test=X_te, y_test=y_te,
        use_dp=True, epsilon=1.0
    )
    server.add_client(client)

# Run federated learning
for round_num in range(5):
    metrics = server.federated_learning_round(model_type='mlp')
    print(f"Round {round_num+1} complete")
```

---

### CICIDSDatasetSimulator

Generates synthetic CIC-IDS2017-like data for testing.

```python
class CICIDSDatasetSimulator:
    @staticmethod
    def generate_cicds_like_data(n_samples=5000, n_features=20, 
                                 random_state=42) -> tuple
    @staticmethod
    def split_by_days(X, y, num_days=5) -> list
```

#### Methods

**`generate_cicds_like_data(n_samples=5000, n_features=20, random_state=42)`**
- Generates synthetic binary classification dataset
- 80% benign, 20% attack (mimics CIC-IDS2017)
- **Args**:
  - `n_samples` (int): Number of samples
  - `n_features` (int): Number of features
  - `random_state` (int): Random seed for reproducibility
- **Returns**: tuple (X, y) - Features and binary labels

**`split_by_days(X, y, num_days=5)`**
- Splits dataset across multiple clients (simulating days)
- Each client gets subset with train/test split
- **Args**:
  - `X` (np.ndarray): Features
  - `y` (np.ndarray): Labels
  - `num_days` (int): Number of clients
- **Returns**: list of dicts with 'X_train', 'y_train', 'X_test', 'y_test'

#### Example
```python
from fl_dp_ids import CICIDSDatasetSimulator

# Generate synthetic data
X, y = CICIDSDatasetSimulator.generate_cicds_like_data(
    n_samples=10000, n_features=20
)

# Split across 5 clients
clients_data = CICIDSDatasetSimulator.split_by_days(X, y, num_days=5)

print(f"Created {len(clients_data)} clients")
print(f"Client 0 training samples: {clients_data[0]['X_train'].shape}")
```

---

## Utility Functions

### dataset.CICIDSDataLoader

Load real CIC-IDS2017 dataset.

```python
loader = CICIDSDataLoader(data_dir='data/cicids2017/')
X_train, X_test, y_train, y_test = loader.load_processed_data(test_size=0.2)
```

---

## Configuration

### Default Configuration (configs/default.yaml)

```yaml
federated_learning:
  num_clients: 5
  num_rounds: 5
  model_type: 'mlp'

differential_privacy:
  use_dp: true
  epsilon: [1.0, 3.0, 8.0]
  delta: 1e-5
  max_grad_norm: 1.0

models:
  random_forest:
    n_estimators: 50
    max_depth: 10
  mlp:
    hidden_layers: [64, 32]
    epochs: 50
    batch_size: 32
  logistic_regression:
    max_iter: 100
    
dataset:
  name: 'cicids2017_synthetic'
  train_size: 0.7
  test_size: 0.3
  random_state: 42
```

---

## Error Handling

Common errors and solutions:

### ValueError: model_type not supported
```python
# Invalid
client.train_local_model(model_type='cnn')

# Valid
client.train_local_model(model_type='mlp')  # Use 'rf', 'mlp', or 'lr'
```

### RuntimeError: No clients registered
```python
# Add clients before training
server = FederatedLearningServer(num_clients=5)
for client in clients:
    server.add_client(client)
```

---

## Performance Tips

1. **Use MLP for better FL performance** - MLPs aggregate better than Random Forests
2. **Adjust batch size** - Larger batches = faster training but higher memory
3. **Tune epsilon** - ε=3.0 balances privacy and utility for most tasks
4. **Normalize features** - Use StandardScaler before federated learning

---

For more information, see [METHODOLOGY.md](METHODOLOGY.md)
