"""
Dataset utilities for CIC-IDS2017 and synthetic data generation.

This module provides functions to download, load, and preprocess the CIC-IDS2017
intrusion detection dataset for federated learning.
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import requests
from pathlib import Path


class CICIDSDataLoader:
    """Load and preprocess CIC-IDS2017 dataset."""
    
    # CIC-IDS2017 file URLs
    DATASET_URLS = {
        'monday': 'https://www.unb.ca/cic/datasets/ids-2017/Monday-WorkingHours.pcap_ISCX.csv',
        'tuesday': 'https://www.unb.ca/cic/datasets/ids-2017/Tuesday-WorkingHours.pcap_ISCX.csv',
        'wednesday': 'https://www.unb.ca/cic/datasets/ids-2017/Wednesday-workingHours.pcap_ISCX.csv',
        'thursday': 'https://www.unb.ca/cic/datasets/ids-2017/Thursday-WorkingHours.pcap_ISCX.csv',
        'friday': 'https://www.unb.ca/cic/datasets/ids-2017/Friday-WorkingHours.pcap_ISCX.csv',
    }
    
    # Features to select (80+ features in CIC-IDS2017)
    SELECTED_FEATURES = [
        'Destination Port', 'Flow Duration', 'Total Fwd Packets',
        'Total Backward Packets', 'Total Length of Fwd Packets',
        'Total Length of Bwd Packets', 'Fwd Packet Length Mean',
        'Bwd Packet Length Mean', 'Fwd Packet Length Std',
        'Bwd Packet Length Std', 'Flow Bytes/s', 'Flow Packets/s',
        'Flow IAT Mean', 'Flow IAT Std', 'Fwd IAT Mean', 'Bwd IAT Mean',
        'Fwd PSH Flags', 'Bwd PSH Flags', 'Fwd URG Flags',
        'Bwd URG Flags', 'Fwd RST Flags', 'Bwd RST Flags',
    ]
    
    def __init__(self, data_dir='data/cicids2017/'):
        """
        Initialize data loader.
        
        Args:
            data_dir (str): Directory containing CIC-IDS2017 CSV files
        """
        self.data_dir = Path(data_dir)
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
    
    def download_dataset(self, output_dir='data/cicids2017/'):
        """Download CIC-IDS2017 dataset files."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for day, url in self.DATASET_URLS.items():
            filepath = output_dir / f"{day.capitalize()}.csv"
            if not filepath.exists():
                print(f"Downloading {day} data...")
                response = requests.get(url)
                with open(filepath, 'wb') as f:
                    f.write(response.content)
                print(f"✓ Downloaded {day}")
    
    def load_processed_data(self, test_size=0.2, random_state=42):
        """
        Load and preprocess CIC-IDS2017 data.
        
        Args:
            test_size (float): Proportion of test set
            random_state (int): Random seed for reproducibility
        
        Returns:
            tuple: (X_train, X_test, y_train, y_test)
        """
        # Load all CSV files
        dfs = []
        for csv_file in self.data_dir.glob('*.csv'):
            df = pd.read_csv(csv_file)
            dfs.append(df)
        
        data = pd.concat(dfs, ignore_index=True)
        
        # Clean column names
        data.columns = data.columns.str.strip()
        
        # Extract features and labels
        X = data[self.SELECTED_FEATURES].values
        y = data['Label'].values
        
        # Binary classification: Normal vs Attack
        y = (y != 'BENIGN').astype(int)
        
        # Handle missing values
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        
        # Split and scale
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        
        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)
        
        return X_train, X_test, y_train, y_test


class CICIDSDatasetSimulator:
    """Generate synthetic data mimicking CIC-IDS2017 characteristics."""
    
    @staticmethod
    def generate_cicds_like_data(n_samples=5000, n_features=20, random_state=42):
        """
        Generate synthetic CIC-IDS2017-like data.
        
        Args:
            n_samples (int): Number of samples
            n_features (int): Number of features
            random_state (int): Random seed
        
        Returns:
            tuple: (X, y) where X is features and y is binary labels
        """
        from sklearn.datasets import make_classification
        
        X, y = make_classification(
            n_samples=n_samples,
            n_features=n_features,
            n_informative=int(n_features * 0.7),
            n_redundant=int(n_features * 0.2),
            n_clusters_per_class=3,
            weights=[0.8, 0.2],  # 80% benign, 20% attack
            random_state=random_state,
            flip_y=0.01
        )
        return X, y
    
    @staticmethod
    def split_by_days(X, y, num_days=5):
        """
        Split data to simulate distribution across days/clients.
        
        Args:
            X (array): Features
            y (array): Labels
            num_days (int): Number of clients/days
        
        Returns:
            list: List of dicts with X_train, X_test, y_train, y_test
        """
        clients_data = []
        samples_per_day = len(X) // num_days
        
        for i in range(num_days):
            start = i * samples_per_day
            end = start + samples_per_day if i < num_days - 1 else len(X)
            
            X_day = X[start:end]
            y_day = y[start:end]
            
            X_train, X_test, y_train, y_test = train_test_split(
                X_day, y_day, test_size=0.2, random_state=42
            )
            
            clients_data.append({
                'X_train': X_train, 'y_train': y_train,
                'X_test': X_test, 'y_test': y_test
            })
        
        return clients_data
