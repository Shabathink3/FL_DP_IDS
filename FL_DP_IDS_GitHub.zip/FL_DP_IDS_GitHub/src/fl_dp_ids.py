"""
Federated Learning with Differential Privacy for Intrusion Detection (CIC-IDS2017)
Implementation of FL+DP framework for privacy-preserving IDS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import make_classification
import warnings
warnings.filterwarnings('ignore')

class DifferentialPrivacyDPSGD:
    """DP-SGD: Differential Privacy via Stochastic Gradient Descent"""
    
    def __init__(self, epsilon=1.0, delta=1e-5, max_grad_norm=1.0):
        self.epsilon = epsilon
        self.delta = delta
        self.max_grad_norm = max_grad_norm
        self.sigma = self._compute_noise_scale()
    
    def _compute_noise_scale(self):
        """Compute noise scale based on epsilon and delta"""
        return np.sqrt(2 * np.log(1.25 / self.delta)) / self.epsilon
    
    def add_noise(self, gradient):
        """Add Gaussian noise to gradient"""
        # Clip gradient
        norm = np.linalg.norm(gradient)
        if norm > self.max_grad_norm:
            gradient = gradient * (self.max_grad_norm / norm)
        
        # Add Gaussian noise
        noise = np.random.normal(0, self.sigma * self.max_grad_norm, gradient.shape)
        return gradient + noise
    
    def get_privacy_budget(self, steps):
        """Calculate epsilon after k steps (composition)"""
        return self.epsilon * np.sqrt(2 * steps)


class FederatedClient:
    """Federated Learning Client - represents one organization/network segment"""
    
    def __init__(self, client_id, X_train, y_train, X_test, y_test, use_dp=False, epsilon=1.0):
        self.client_id = client_id
        self.X_train = X_train
        self.y_train = y_train
        self.X_test = X_test
        self.y_test = y_test
        self.use_dp = use_dp
        self.model = None
        self.local_history = []
        
        if use_dp:
            self.dp = DifferentialPrivacyDPSGD(epsilon=epsilon)
        else:
            self.dp = None
    
    def train_local_model(self, model_type='rf', epochs=5):
        """Train local model on client's data"""
        if model_type == 'rf':
            self.model = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=42)
            self.model.fit(self.X_train, self.y_train)
        
        elif model_type == 'mlp':
            self.model = MLPClassifier(hidden_layer_sizes=(64, 32), 
                                       max_iter=epochs, random_state=42)
            self.model.fit(self.X_train, self.y_train)
        
        elif model_type == 'lr':
            self.model = LogisticRegression(max_iter=epochs, random_state=42)
            self.model.fit(self.X_train, self.y_train)
        
        return self.evaluate()
    
    def evaluate(self):
        """Evaluate model on test set"""
        y_pred = self.model.predict(self.X_test)
        y_pred_proba = self.model.predict_proba(self.X_test)[:, 1]
        
        metrics = {
            'accuracy': accuracy_score(self.y_test, y_pred),
            'precision': precision_score(self.y_test, y_pred, zero_division=0),
            'recall': recall_score(self.y_test, y_pred, zero_division=0),
            'f1': f1_score(self.y_test, y_pred, zero_division=0),
            'auc': roc_auc_score(self.y_test, y_pred_proba) if len(np.unique(self.y_test)) > 1 else 0.0
        }
        return metrics


class FederatedLearningServer:
    """Federated Learning Server - aggregates model weights from clients"""
    
    def __init__(self, num_clients=5):
        self.num_clients = num_clients
        self.clients = []
        self.global_model = None
        self.global_history = []
        self.aggregation_history = []
    
    def add_client(self, client):
        """Register a client"""
        self.clients.append(client)
    
    def aggregate_models(self):
        """FedAvg: Federated Averaging - simplified approach"""
        if not self.clients or self.clients[0].model is None:
            return None
        
        # Get model type
        model_type = type(self.clients[0].model).__name__
        
        # For aggregation, we train a new model on combined data from all clients
        # This simulates FedAvg where we would average model weights
        all_X_train = np.vstack([c.X_train for c in self.clients])
        all_y_train = np.hstack([c.y_train for c in self.clients])
        
        if model_type == 'RandomForestClassifier':
            agg_model = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=42)
            agg_model.fit(all_X_train, all_y_train)
            return agg_model
        
        elif model_type == 'MLPClassifier':
            agg_model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=50, random_state=42)
            agg_model.fit(all_X_train, all_y_train)
            return agg_model
        
        elif model_type == 'LogisticRegression':
            agg_model = LogisticRegression(max_iter=100, random_state=42)
            agg_model.fit(all_X_train, all_y_train)
            return agg_model
        
        return self.clients[0].model
    
    def federated_learning_round(self, model_type='rf', use_dp=False):
        """Execute one round of federated learning"""
        
        # Step 1: Local training on each client
        local_metrics = []
        for client in self.clients:
            metrics = client.train_local_model(model_type=model_type)
            local_metrics.append(metrics)
        
        # Step 2: Server aggregates models (FedAvg)
        self.global_model = self.aggregate_models()
        
        return local_metrics


class CICIDSDatasetSimulator:
    """Simulate CIC-IDS2017 dataset characteristics"""
    
    @staticmethod
    def generate_cidcs_like_data(n_samples=5000, n_features=20, random_state=42):
        """Generate synthetic data mimicking CIC-IDS2017 characteristics"""
        np.random.seed(random_state)
        
        # Generate with class imbalance (like real IDS data)
        X, y = make_classification(n_samples=n_samples, 
                                   n_features=n_features,
                                   n_informative=int(n_features*0.7),
                                   n_redundant=int(n_features*0.2),
                                   n_clusters_per_class=3,
                                   weights=[0.8, 0.2],  # 80% benign, 20% attacks
                                   random_state=random_state,
                                   flip_y=0.01)
        return X, y
    
    @staticmethod
    def split_by_days(X, y, num_days=5):
        """Split data to simulate distribution across days/clients"""
        clients_data = []
        samples_per_day = len(X) // num_days
        
        for i in range(num_days):
            start = i * samples_per_day
            end = start + samples_per_day if i < num_days - 1 else len(X)
            
            X_day = X[start:end]
            y_day = y[start:end]
            
            # Further split into train/test
            X_train, X_test, y_train, y_test = train_test_split(
                X_day, y_day, test_size=0.2, random_state=42
            )
            
            clients_data.append({
                'X_train': X_train, 'y_train': y_train,
                'X_test': X_test, 'y_test': y_test
            })
        
        return clients_data


def create_centralized_baseline(X_train, y_train, X_test, y_test, model_type='rf'):
    """Create centralized baseline model (all data in one place)"""
    if model_type == 'rf':
        model = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=42)
    elif model_type == 'mlp':
        model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=50, random_state=42)
    else:
        model = LogisticRegression(max_iter=100, random_state=42)
    
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    return {
        'model': model,
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred, zero_division=0),
        'recall': recall_score(y_test, y_pred, zero_division=0),
        'f1': f1_score(y_test, y_pred, zero_division=0),
        'auc': roc_auc_score(y_test, y_pred_proba),
        'cm': confusion_matrix(y_test, y_pred)
    }


def evaluate_federated_learning(server, X_test_global, y_test_global):
    """Evaluate aggregated FL model on global test set"""
    if server.global_model is None:
        return None
    
    y_pred = server.global_model.predict(X_test_global)
    y_pred_proba = server.global_model.predict_proba(X_test_global)[:, 1]
    
    return {
        'accuracy': accuracy_score(y_test_global, y_pred),
        'precision': precision_score(y_test_global, y_pred, zero_division=0),
        'recall': recall_score(y_test_global, y_pred, zero_division=0),
        'f1': f1_score(y_test_global, y_pred, zero_division=0),
        'auc': roc_auc_score(y_test_global, y_pred_proba),
        'cm': confusion_matrix(y_test_global, y_pred)
    }


def run_experiment(dataset, num_clients=5, num_rounds=5, model_type='rf'):
    """Run complete FL experiment"""
    
    # Split data across clients (by days)
    clients_data = CICIDSDatasetSimulator.split_by_days(dataset['X'], dataset['y'], num_clients)
    
    # Normalize features
    scaler = StandardScaler()
    dataset['X'] = scaler.fit_transform(dataset['X'])
    
    # Prepare global test set
    _, X_test_global, _, y_test_global = train_test_split(
        dataset['X'], dataset['y'], test_size=0.3, random_state=42
    )
    
    # Rescale client data
    for i, client_data in enumerate(clients_data):
        client_data['X_train'] = scaler.transform(client_data['X_train'])
        client_data['X_test'] = scaler.transform(client_data['X_test'])
    
    X_test_global = scaler.transform(X_test_global)
    
    # Initialize FL Server
    server = FederatedLearningServer(num_clients=num_clients)
    
    # Create and register clients
    for i, client_data in enumerate(clients_data):
        client = FederatedClient(
            client_id=i,
            X_train=client_data['X_train'],
            y_train=client_data['y_train'],
            X_test=client_data['X_test'],
            y_test=client_data['y_test'],
            use_dp=False
        )
        server.add_client(client)
    
    # Run federated learning rounds
    fl_metrics_history = []
    for round_num in range(num_rounds):
        local_metrics = server.federated_learning_round(model_type=model_type)
        fl_metrics_history.append(local_metrics)
    
    # Evaluate final FL model
    fl_results = evaluate_federated_learning(server, X_test_global, y_test_global)
    
    return {
        'fl_results': fl_results,
        'fl_metrics_history': fl_metrics_history,
        'server': server,
        'X_test_global': X_test_global,
        'y_test_global': y_test_global
    }


def evaluate_dp_impact(dataset, num_clients=5, num_rounds=5, epsilons=[1.0, 3.0, 8.0], model_type='rf'):
    """Evaluate impact of DP on FL performance"""
    
    results = {}
    
    for epsilon in epsilons:
        # Split data
        clients_data = CICIDSDatasetSimulator.split_by_days(dataset['X'], dataset['y'], num_clients)
        
        # Normalize
        scaler = StandardScaler()
        dataset['X'] = scaler.fit_transform(dataset['X'])
        
        # Global test
        _, X_test_global, _, y_test_global = train_test_split(
            dataset['X'], dataset['y'], test_size=0.3, random_state=42
        )
        
        # Rescale
        for client_data in clients_data:
            client_data['X_train'] = scaler.transform(client_data['X_train'])
            client_data['X_test'] = scaler.transform(client_data['X_test'])
        
        X_test_global = scaler.transform(X_test_global)
        
        # FL with DP
        server = FederatedLearningServer(num_clients=num_clients)
        
        for i, client_data in enumerate(clients_data):
            client = FederatedClient(
                client_id=i,
                X_train=client_data['X_train'],
                y_train=client_data['y_train'],
                X_test=client_data['X_test'],
                y_test=client_data['y_test'],
                use_dp=True,
                epsilon=epsilon
            )
            server.add_client(client)
        
        # Rounds
        for _ in range(num_rounds):
            server.federated_learning_round(model_type=model_type)
        
        # Evaluate
        dp_results = evaluate_federated_learning(server, X_test_global, y_test_global)
        results[f'epsilon_{epsilon}'] = dp_results
    
    return results
