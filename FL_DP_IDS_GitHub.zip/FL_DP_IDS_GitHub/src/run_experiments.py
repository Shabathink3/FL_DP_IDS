"""
Experiment Pipeline: Federated Learning vs Centralized vs FL+DP
"""

import numpy as np
import pandas as pd
import json
from fl_dp_ids import (
    CICIDSDatasetSimulator, create_centralized_baseline,
    run_experiment, evaluate_dp_impact, StandardScaler,
    train_test_split
)
import matplotlib.pyplot as plt
import seaborn as sns

def run_all_experiments():
    """Run complete experiment suite"""
    
    print("="*70)
    print("FEDERATED LEARNING + DIFFERENTIAL PRIVACY FOR INTRUSION DETECTION")
    print("Experiment Suite: CIC-IDS2017 Dataset Simulation")
    print("="*70)
    
    # Generate synthetic CIC-IDS2017-like data
    print("\n[1/4] Generating CIC-IDS2017-like dataset...")
    X, y = CICIDSDatasetSimulator.generate_cidcs_like_data(n_samples=10000, n_features=20)
    dataset = {'X': X, 'y': y}
    print(f"    Generated: {X.shape[0]} samples, {X.shape[1]} features")
    print(f"    Class distribution: {np.bincount(y)}")
    
    # Prepare data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    results = {
        'timestamp': pd.Timestamp.now().isoformat(),
        'dataset_info': {
            'total_samples': len(X),
            'train_samples': len(X_train),
            'test_samples': len(X_test),
            'features': X.shape[1],
            'class_distribution': {0: int(np.sum(y == 0)), 1: int(np.sum(y == 1))}
        },
        'baselines': {},
        'federated_learning': {},
        'federated_learning_with_dp': {}
    }
    
    # ==================== BASELINE 1: CENTRALIZED ML ====================
    print("\n[2/4] Running Centralized ML Baselines...")
    print("    [2.1] Centralized Random Forest...")
    
    rf_baseline = create_centralized_baseline(X_train, y_train, X_test, y_test, model_type='rf')
    results['baselines']['centralized_rf'] = {
        'accuracy': float(rf_baseline['accuracy']),
        'precision': float(rf_baseline['precision']),
        'recall': float(rf_baseline['recall']),
        'f1': float(rf_baseline['f1']),
        'auc': float(rf_baseline['auc']),
        'cm': rf_baseline['cm'].tolist()
    }
    print(f"        Accuracy: {rf_baseline['accuracy']:.4f}, F1: {rf_baseline['f1']:.4f}, AUC: {rf_baseline['auc']:.4f}")
    
    print("    [2.2] Centralized MLP...")
    mlp_baseline = create_centralized_baseline(X_train, y_train, X_test, y_test, model_type='mlp')
    results['baselines']['centralized_mlp'] = {
        'accuracy': float(mlp_baseline['accuracy']),
        'precision': float(mlp_baseline['precision']),
        'recall': float(mlp_baseline['recall']),
        'f1': float(mlp_baseline['f1']),
        'auc': float(mlp_baseline['auc']),
        'cm': mlp_baseline['cm'].tolist()
    }
    print(f"        Accuracy: {mlp_baseline['accuracy']:.4f}, F1: {mlp_baseline['f1']:.4f}, AUC: {mlp_baseline['auc']:.4f}")
    
    print("    [2.3] Centralized Logistic Regression...")
    from fl_dp_ids import LogisticRegression
    lr_baseline = create_centralized_baseline(X_train, y_train, X_test, y_test, model_type='lr')
    results['baselines']['centralized_lr'] = {
        'accuracy': float(lr_baseline['accuracy']),
        'precision': float(lr_baseline['precision']),
        'recall': float(lr_baseline['recall']),
        'f1': float(lr_baseline['f1']),
        'auc': float(lr_baseline['auc']),
        'cm': lr_baseline['cm'].tolist()
    }
    print(f"        Accuracy: {lr_baseline['accuracy']:.4f}, F1: {lr_baseline['f1']:.4f}, AUC: {lr_baseline['auc']:.4f}")
    
    # ==================== BASELINE 2: FL WITHOUT DP ====================
    print("\n[3/4] Running Federated Learning (NO DP)...")
    print("    [3.1] FL with Random Forest...")
    
    fl_rf_results = run_experiment(dataset, num_clients=5, num_rounds=5, model_type='rf')
    results['federated_learning']['fl_rf'] = {
        'accuracy': float(fl_rf_results['fl_results']['accuracy']),
        'precision': float(fl_rf_results['fl_results']['precision']),
        'recall': float(fl_rf_results['fl_results']['recall']),
        'f1': float(fl_rf_results['fl_results']['f1']),
        'auc': float(fl_rf_results['fl_results']['auc']),
        'cm': fl_rf_results['fl_results']['cm'].tolist()
    }
    print(f"        Accuracy: {fl_rf_results['fl_results']['accuracy']:.4f}, F1: {fl_rf_results['fl_results']['f1']:.4f}")
    
    print("    [3.2] FL with MLP...")
    fl_mlp_results = run_experiment(dataset, num_clients=5, num_rounds=5, model_type='mlp')
    results['federated_learning']['fl_mlp'] = {
        'accuracy': float(fl_mlp_results['fl_results']['accuracy']),
        'precision': float(fl_mlp_results['fl_results']['precision']),
        'recall': float(fl_mlp_results['fl_results']['recall']),
        'f1': float(fl_mlp_results['fl_results']['f1']),
        'auc': float(fl_mlp_results['fl_results']['auc']),
        'cm': fl_mlp_results['fl_results']['cm'].tolist()
    }
    print(f"        Accuracy: {fl_mlp_results['fl_results']['accuracy']:.4f}, F1: {fl_mlp_results['fl_results']['f1']:.4f}")
    
    # ==================== FL WITH DP ====================
    print("\n[4/4] Running Federated Learning WITH Differential Privacy...")
    print("    Testing epsilon values: [1.0, 3.0, 8.0]")
    
    dp_results = evaluate_dp_impact(dataset, num_clients=5, num_rounds=5, 
                                     epsilons=[1.0, 3.0, 8.0], model_type='rf')
    
    for epsilon_key, metrics in dp_results.items():
        epsilon_val = float(epsilon_key.split('_')[1])
        results['federated_learning_with_dp'][f'fl_dp_epsilon_{epsilon_val}'] = {
            'epsilon': epsilon_val,
            'accuracy': float(metrics['accuracy']),
            'precision': float(metrics['precision']),
            'recall': float(metrics['recall']),
            'f1': float(metrics['f1']),
            'auc': float(metrics['auc']),
            'cm': metrics['cm'].tolist()
        }
        print(f"        ε={epsilon_val}: Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}")
    
    return results


def generate_visualizations(results, output_dir='/home/claude'):
    """Generate visualization plots"""
    
    print("\n[VISUALIZATIONS] Generating plots...")
    
    # Extract metrics for comparison
    baselines = results['baselines']
    fl_models = results['federated_learning']
    fl_dp_models = results['federated_learning_with_dp']
    
    # Prepare data for plotting
    models_names = []
    accuracies = []
    f1_scores = []
    precisions = []
    recalls = []
    aucs = []
    
    # Baselines
    for name, metrics in baselines.items():
        models_names.append(name.replace('centralized_', 'Centralized\n').upper())
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # FL
    for name, metrics in fl_models.items():
        models_names.append(name.replace('fl_', 'FL\n').upper())
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # FL+DP
    for name, metrics in fl_dp_models.items():
        epsilon = metrics['epsilon']
        models_names.append(f'FL+DP\n(ε={epsilon})')
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # Plot 1: Comparison of all metrics
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('Federated Learning with Differential Privacy: Performance Metrics', fontsize=14, fontweight='bold')
    
    metrics_list = [
        ('Accuracy', accuracies),
        ('Precision', precisions),
        ('Recall', recalls),
        ('F1-Score', f1_scores),
        ('AUC-ROC', aucs)
    ]
    
    for idx, (metric_name, metric_values) in enumerate(metrics_list):
        ax = axes[idx // 3, idx % 3]
        colors = ['#1f77b4']*3 + ['#ff7f0e']*2 + ['#2ca02c']*3
        bars = ax.bar(range(len(models_names)), metric_values, color=colors[:len(models_names)])
        ax.set_ylabel(metric_name, fontweight='bold')
        ax.set_xticks(range(len(models_names)))
        ax.set_xticklabels(models_names, rotation=45, ha='right', fontsize=9)
        ax.set_ylim([0, 1])
        ax.grid(axis='y', alpha=0.3)
        
        # Add value labels on bars
        for bar, val in zip(bars, metric_values):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{val:.3f}', ha='center', va='bottom', fontsize=8)
    
    # Remove extra subplot
    fig.delaxes(axes[1, 2])
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/01_performance_comparison.png', dpi=300, bbox_inches='tight')
    print("    Saved: 01_performance_comparison.png")
    plt.close()
    
    # Plot 2: Accuracy vs Privacy Trade-off
    fig, ax = plt.subplots(figsize=(10, 6))
    
    eps_values = []
    acc_values = []
    for name, metrics in fl_dp_models.items():
        eps_values.append(metrics['epsilon'])
        acc_values.append(metrics['accuracy'])
    
    ax.plot(eps_values, acc_values, 'o-', linewidth=2, markersize=10, color='#d62728')
    ax.axhline(y=baselines['centralized_rf']['accuracy'], color='#1f77b4', 
               linestyle='--', label='Centralized RF Baseline', linewidth=2)
    
    ax.set_xlabel('Privacy Budget (ε)', fontweight='bold', fontsize=12)
    ax.set_ylabel('Accuracy', fontweight='bold', fontsize=12)
    ax.set_title('Privacy-Utility Trade-off: FL+DP Accuracy vs Privacy Budget', fontweight='bold', fontsize=13)
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=11)
    
    for x, y in zip(eps_values, acc_values):
        ax.annotate(f'{y:.3f}', (x, y), textcoords="offset points", xytext=(0,10), ha='center')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/02_privacy_utility_tradeoff.png', dpi=300, bbox_inches='tight')
    print("    Saved: 02_privacy_utility_tradeoff.png")
    plt.close()
    
    # Plot 3: Confusion matrices for key models
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    fig.suptitle('Confusion Matrices: Centralized RF vs FL vs FL+DP', fontweight='bold')
    
    cm_data = [
        ('Centralized RF', baselines['centralized_rf']['cm']),
        ('FL (RF)', fl_models['fl_rf']['cm']),
        ('FL+DP (ε=1.0)', fl_dp_models['fl_dp_epsilon_1.0']['cm'])
    ]
    
    for idx, (name, cm) in enumerate(cm_data):
        ax = axes[idx]
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax, cbar=False)
        ax.set_title(name, fontweight='bold')
        ax.set_xlabel('Predicted')
        ax.set_ylabel('Actual')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/03_confusion_matrices.png', dpi=300, bbox_inches='tight')
    print("    Saved: 03_confusion_matrices.png")
    plt.close()
    
    print("    All visualizations generated successfully!")


if __name__ == "__main__":
    # Run experiments
    results = run_all_experiments()
    
    # Generate visualizations
    generate_visualizations(results)
    
    # Save results to JSON
    with open('/home/claude/experiment_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n" + "="*70)
    print("EXPERIMENT COMPLETE")
    print("Results saved to: /home/claude/experiment_results.json")
    print("Visualizations saved to: /home/claude/0X_*.png")
    print("="*70)
