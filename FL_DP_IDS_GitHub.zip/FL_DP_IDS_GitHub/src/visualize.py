"""
Visualization utilities for FL+DP experimental results.

Provides functions to create publication-quality plots for:
- Performance metrics comparison
- Privacy-utility trade-off curves
- Confusion matrices
- ROC curves
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc


def plot_performance_comparison(results, output_path='performance_comparison.png'):
    """
    Plot comparison of performance metrics across all approaches.
    
    Args:
        results (dict): Results dictionary from experiments
        output_path (str): Path to save figure
    """
    # Extract metrics
    models = []
    accuracies = []
    f1_scores = []
    precisions = []
    recalls = []
    aucs = []
    
    # Centralized baselines
    for name, metrics in results['baselines'].items():
        models.append(name.replace('centralized_', '').upper())
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # Federated Learning
    for name, metrics in results['federated_learning'].items():
        models.append(name.replace('fl_', 'FL-').upper())
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # FL+DP
    for name, metrics in results['federated_learning_with_dp'].items():
        eps = metrics['epsilon']
        models.append(f'FL+DP\n(ε={eps})')
        accuracies.append(metrics['accuracy'])
        f1_scores.append(metrics['f1'])
        precisions.append(metrics['precision'])
        recalls.append(metrics['recall'])
        aucs.append(metrics['auc'])
    
    # Create plots
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('FL+DP for IDS: Performance Metrics Comparison', fontweight='bold', fontsize=14)
    
    metrics_data = [
        ('Accuracy', accuracies),
        ('Precision', precisions),
        ('Recall', recalls),
        ('F1-Score', f1_scores),
        ('AUC-ROC', aucs),
    ]
    
    colors = ['#1f77b4']*3 + ['#ff7f0e']*2 + ['#2ca02c']*3
    
    for idx, (metric_name, values) in enumerate(metrics_data):
        ax = axes[idx // 3, idx % 3]
        bars = ax.bar(range(len(models)), values, color=colors[:len(models)])
        ax.set_ylabel(metric_name, fontweight='bold')
        ax.set_xticks(range(len(models)))
        ax.set_xticklabels(models, rotation=45, ha='right', fontsize=9)
        ax.set_ylim([0, 1])
        ax.grid(axis='y', alpha=0.3)
        
        # Add value labels
        for bar, val in zip(bars, values):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{val:.3f}', ha='center', va='bottom', fontsize=8)
    
    # Remove extra subplot
    fig.delaxes(axes[1, 2])
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {output_path}")
    plt.close()


def plot_privacy_utility_tradeoff(epsilon_values, accuracies, 
                                  baseline_accuracy=None, 
                                  output_path='privacy_utility.png'):
    """
    Plot privacy-utility trade-off curve.
    
    Args:
        epsilon_values (list): Privacy budget values
        accuracies (list): Corresponding accuracies
        baseline_accuracy (float): Centralized baseline accuracy
        output_path (str): Path to save figure
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Plot FL+DP accuracies
    ax.plot(epsilon_values, accuracies, 'o-', linewidth=2, markersize=10, 
           label='FL+DP Accuracy', color='#d62728')
    
    # Plot baseline
    if baseline_accuracy:
        ax.axhline(y=baseline_accuracy, color='#1f77b4', linestyle='--', 
                  linewidth=2, label='Centralized Baseline')
    
    ax.set_xlabel('Privacy Budget (ε)', fontweight='bold', fontsize=12)
    ax.set_ylabel('Accuracy', fontweight='bold', fontsize=12)
    ax.set_title('Privacy-Utility Trade-off: FL+DP Accuracy vs Privacy Budget', 
                fontweight='bold', fontsize=13)
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=11)
    
    # Add value annotations
    for x, y in zip(epsilon_values, accuracies):
        ax.annotate(f'{y:.3f}', (x, y), textcoords="offset points", 
                   xytext=(0, 10), ha='center')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {output_path}")
    plt.close()


def plot_confusion_matrices(y_test, predictions_list, model_names, 
                           output_path='confusion_matrices.png'):
    """
    Plot confusion matrices for multiple models.
    
    Args:
        y_test (array): True labels
        predictions_list (list): List of prediction arrays
        model_names (list): Names of models
        output_path (str): Path to save figure
    """
    n_models = len(predictions_list)
    fig, axes = plt.subplots(1, n_models, figsize=(5*n_models, 4))
    
    if n_models == 1:
        axes = [axes]
    
    fig.suptitle('Confusion Matrices: Model Comparison', fontweight='bold', fontsize=13)
    
    for ax, y_pred, name in zip(axes, predictions_list, model_names):
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax, cbar=False)
        ax.set_title(name, fontweight='bold')
        ax.set_xlabel('Predicted')
        ax.set_ylabel('Actual')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {output_path}")
    plt.close()


def plot_roc_curves(y_test, predictions_proba_list, model_names, 
                    output_path='roc_curves.png'):
    """
    Plot ROC curves for multiple models.
    
    Args:
        y_test (array): True labels
        predictions_proba_list (list): List of probability predictions
        model_names (list): Names of models
        output_path (str): Path to save figure
    """
    fig, ax = plt.subplots(figsize=(10, 8))
    
    colors = plt.cm.Set1(np.linspace(0, 1, len(predictions_proba_list)))
    
    for y_proba, name, color in zip(predictions_proba_list, model_names, colors):
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, label=f'{name} (AUC={roc_auc:.3f})', 
               color=color, linewidth=2)
    
    # Plot random classifier
    ax.plot([0, 1], [0, 1], 'k--', label='Random Classifier', linewidth=1)
    
    ax.set_xlabel('False Positive Rate', fontweight='bold', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontweight='bold', fontsize=12)
    ax.set_title('ROC Curves: Model Comparison', fontweight='bold', fontsize=13)
    ax.legend(fontsize=10)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {output_path}")
    plt.close()
