"""
Federated Learning with Differential Privacy for Intrusion Detection (FL_DP_IDS)

A production-grade implementation of Federated Learning combined with Differential Privacy
for privacy-preserving intrusion detection systems.

Main Components:
    - FederatedLearningServer: Coordinates federated learning rounds
    - FederatedClient: Trains models locally on client data
    - DifferentialPrivacyDPSGD: Applies differential privacy to gradients
    - CICIDSDatasetSimulator: Generates synthetic CIC-IDS2017-like data

Example:
    >>> from fl_dp_ids import FederatedLearningServer, FederatedClient
    >>> server = FederatedLearningServer(num_clients=5)
    >>> # Create clients and add to server
    >>> # Run federated learning rounds
    >>> server.federated_learning_round(model_type='mlp')

Documentation:
    https://github.com/username/FL_DP_IDS

License:
    MIT License - See LICENSE file for details
"""

__title__ = "fl_dp_ids"
__version__ = "1.0.0"
__author__ = "FL_DP_IDS Contributors"
__description__ = "Federated Learning with Differential Privacy for Intrusion Detection"
__url__ = "https://github.com/username/FL_DP_IDS"
__license__ = "MIT"

# Import main classes for easy access
try:
    from src.fl_dp_ids import (
        DifferentialPrivacyDPSGD,
        FederatedClient,
        FederatedLearningServer,
        CICIDSDatasetSimulator,
    )
    
    __all__ = [
        "DifferentialPrivacyDPSGD",
        "FederatedClient",
        "FederatedLearningServer",
        "CICIDSDatasetSimulator",
    ]
except ImportError:
    # If imports fail, provide helpful message
    __all__ = []
    import warnings
    warnings.warn(
        "Could not import main classes. Make sure all dependencies are installed: "
        "pip install -r requirements.txt"
    )
