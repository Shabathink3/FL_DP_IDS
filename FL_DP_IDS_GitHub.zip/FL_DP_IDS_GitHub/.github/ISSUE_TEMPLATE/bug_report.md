---
name: Bug Report
about: Report a bug to help us improve
title: "[BUG] Brief description of the bug"
labels: bug
assignees: ''

---

## Description
<!-- A clear and concise description of what the bug is. -->

## Steps to Reproduce
<!-- Steps to reproduce the behavior: -->
1. ...
2. ...
3. ...

## Expected Behavior
<!-- A clear and concise description of what you expected to happen. -->

## Actual Behavior
<!-- A clear and concise description of what actually happened. -->

## Environment
<!-- Please provide environment details -->
- **OS**: (e.g., Ubuntu 20.04, macOS 12, Windows 10)
- **Python Version**: (e.g., 3.9, 3.10)
- **FL_DP_IDS Version**: (e.g., 1.0.0)
- **Package Manager**: (pip / conda)

## Error Message/Traceback
```
Paste the complete error message or traceback here
```

## Minimal Reproducible Example
```python
# Minimal code that reproduces the bug
```

## Screenshots
<!-- If applicable, add screenshots to help explain your problem. -->

## Additional Context
<!-- Any other context about the problem here? -->

## Possible Solution
<!-- Optional: Do you have an idea of what might be causing the bug or how to fix it? -->
